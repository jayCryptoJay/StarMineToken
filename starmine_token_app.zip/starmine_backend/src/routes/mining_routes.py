from flask import Blueprint, jsonify, request
from src.models.models import User, MiningStats, Equipment, PowerUp, MiningSession, Transaction
from src.main import db
from datetime import datetime, timedelta
import uuid
import math
import json

mining_bp = Blueprint('mining', __name__)

@mining_bp.route('/start', methods=['POST'])
def start_mining():
    """Start a new mining session for the user"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if user has mining stats
    if not user.mining_stats:
        # Create mining stats if not exists
        mining_stats = MiningStats(user_id=user.id)
        db.session.add(mining_stats)
        db.session.commit()
    else:
        mining_stats = user.mining_stats
    
    # Check if user has equipment
    if not user.equipment:
        # Create default equipment if not exists
        equipment = Equipment(user_id=user.id)
        db.session.add(equipment)
        db.session.commit()
    else:
        equipment = user.equipment
    
    # Check if user is in cooldown
    if mining_stats.is_cooldown_active():
        return jsonify({
            "error": "Mining on cooldown",
            "cooldown_end": mining_stats.cooldown_end.isoformat(),
            "time_remaining": (mining_stats.cooldown_end - datetime.utcnow()).total_seconds()
        }), 400
    
    # Check if there's an active session
    if mining_stats.is_session_active():
        return jsonify({
            "error": "Mining session already active",
            "session": {
                "start": mining_stats.session_start.isoformat(),
                "end": mining_stats.session_end.isoformat(),
                "time_remaining": mining_stats.get_time_remaining()
            }
        }), 400
    
    # Calculate mining rate
    mining_rate = calculate_mining_rate(user)
    
    # Start new session
    now = datetime.utcnow()
    session_duration = equipment.energy_duration  # In seconds
    
    mining_stats.session_start = now
    mining_stats.session_end = now + timedelta(seconds=session_duration)
    mining_stats.current_rate = mining_rate
    mining_stats.last_calculation = now
    
    # Create mining session record
    session = MiningSession(
        user_id=user.id,
        end_time=mining_stats.session_end
    )
    db.session.add(session)
    
    # Update user's last active timestamp
    user.last_active = now
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Mining session started",
        "session": {
            "start": mining_stats.session_start.isoformat(),
            "end": mining_stats.session_end.isoformat(),
            "duration": session_duration,
            "mining_rate": mining_rate
        }
    }), 200

@mining_bp.route('/status', methods=['GET'])
def mining_status():
    """Get the current mining status for a user"""
    telegram_id = request.args.get('telegram_id')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if user has mining stats
    if not user.mining_stats:
        return jsonify({"error": "User has no mining stats"}), 404
    
    mining_stats = user.mining_stats
    
    # Calculate current status
    now = datetime.utcnow()
    
    # Update user's last active timestamp
    user.last_active = now
    db.session.commit()
    
    if mining_stats.is_session_active():
        # Calculate stardust mined so far
        elapsed_time = (now - mining_stats.last_calculation).total_seconds()
        stardust_mined = (mining_stats.current_rate * elapsed_time) / 3600  # Convert to hourly rate
        
        # Get remaining time
        remaining_time = mining_stats.get_time_remaining()
        
        # Get total session duration
        total_duration = (mining_stats.session_end - mining_stats.session_start).total_seconds()
        
        # Calculate progress percentage
        progress = ((total_duration - remaining_time) / total_duration) * 100
        
        return jsonify({
            "status": "active",
            "session_start": mining_stats.session_start.isoformat(),
            "session_end": mining_stats.session_end.isoformat(),
            "time_elapsed": total_duration - remaining_time,
            "time_remaining": remaining_time,
            "progress": progress,
            "mining_rate": mining_stats.current_rate,
            "estimated_stardust": stardust_mined,
            "total_stardust": user.stardust_balance
        }), 200
    elif mining_stats.is_cooldown_active():
        return jsonify({
            "status": "cooldown",
            "cooldown_end": mining_stats.cooldown_end.isoformat(),
            "time_remaining": (mining_stats.cooldown_end - now).total_seconds(),
            "total_stardust": user.stardust_balance
        }), 200
    else:
        return jsonify({
            "status": "idle",
            "total_stardust": user.stardust_balance
        }), 200

@mining_bp.route('/collect', methods=['POST'])
def collect_stardust():
    """Collect mined stardust and end the current session"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if user has mining stats
    if not user.mining_stats:
        return jsonify({"error": "User has no mining stats"}), 404
    
    mining_stats = user.mining_stats
    
    # Check if there's an active session
    if not mining_stats.is_session_active():
        return jsonify({"error": "No active mining session"}), 400
    
    # Calculate stardust mined
    now = datetime.utcnow()
    session_duration = min(
        (now - mining_stats.session_start).total_seconds(),
        (mining_stats.session_end - mining_stats.session_start).total_seconds()
    )
    
    mining_rate = mining_stats.current_rate
    stardust_mined = (mining_rate * session_duration) / 3600  # Convert to hourly rate
    
    # Apply storage limits
    if user.equipment:
        max_storage = user.equipment.storage_capacity
        new_balance = min(user.stardust_balance + stardust_mined, max_storage)
        stardust_gained = new_balance - user.stardust_balance
    else:
        new_balance = user.stardust_balance + stardust_mined
        stardust_gained = stardust_mined
    
    # Update user balance
    user.stardust_balance = new_balance
    
    # End session and set cooldown
    mining_stats.session_start = None
    mining_stats.session_end = None
    mining_stats.cooldown_end = now + timedelta(hours=1)  # 1 hour cooldown
    mining_stats.total_mined += stardust_gained
    
    # Find and update the mining session record
    session = MiningSession.query.filter_by(
        user_id=user.id, 
        completed=False
    ).order_by(MiningSession.start_time.desc()).first()
    
    if session:
        session.complete(stardust_gained, mining_rate)
    
    # Create transaction record
    transaction = Transaction(
        user_id=user.id,
        type="mining",
        amount=stardust_gained,
        currency="stardust",
        description="Mining session reward",
        metadata={
            "session_duration": session_duration,
            "mining_rate": mining_rate
        }
    )
    db.session.add(transaction)
    
    # Update user's last active timestamp
    user.last_active = now
    
    # Add experience points (1 XP per stardust)
    experience_gained = math.floor(stardust_gained)
    user.experience += experience_gained
    
    # Check for level up
    check_level_up(user)
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Mining session completed",
        "stardust_gained": stardust_gained,
        "new_balance": user.stardust_balance,
        "cooldown_end": mining_stats.cooldown_end.isoformat(),
        "experience_gained": experience_gained,
        "level": user.level
    }), 200

@mining_bp.route('/boost', methods=['POST'])
def boost_mining():
    """Apply a power-up to boost mining rate"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    power_up_id = data.get('power_up_id')
    
    if not telegram_id or not power_up_id:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Find power-up
    power_up = PowerUp.query.filter_by(id=power_up_id, user_id=user.id).first()
    if not power_up:
        return jsonify({"error": "Power-up not found or doesn't belong to user"}), 404
    
    # Check if power-up is already active
    if power_up.is_active:
        return jsonify({"error": "Power-up is already active"}), 400
    
    # Activate power-up
    power_up.activate()
    
    # Recalculate mining rate if there's an active session
    if user.mining_stats and user.mining_stats.is_session_active():
        new_rate = calculate_mining_rate(user)
        user.mining_stats.current_rate = new_rate
    
    # Update user's last active timestamp
    user.last_active = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Power-up activated",
        "power_up": power_up.to_dict(),
        "new_mining_rate": user.mining_stats.current_rate if user.mining_stats else None
    }), 200

@mining_bp.route('/mini-game/start', methods=['POST'])
def start_mini_game():
    """Start a mini-game for bonus stardust"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    game_type = data.get('game_type')
    
    if not telegram_id or not game_type:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if mini-game type is valid
    valid_games = ["stellar_tap", "cosmic_swipe", "asteroid_field", "nebula_puzzle"]
    if game_type not in valid_games:
        return jsonify({"error": "Invalid mini-game type"}), 400
    
    # Generate a unique game session ID
    game_id = str(uuid.uuid4())
    
    # Update user's last active timestamp
    user.last_active = datetime.utcnow()
    db.session.commit()
    
    # Return game configuration
    game_config = get_mini_game_config(game_type, user.level)
    
    return jsonify({
        "success": True,
        "game_id": game_id,
        "game_type": game_type,
        "config": game_config,
        "max_reward": calculate_max_mini_game_reward(user, game_type)
    }), 200

@mining_bp.route('/mini-game/complete', methods=['POST'])
def complete_mini_game():
    """Complete a mini-game and award stardust"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    game_id = data.get('game_id')
    game_type = data.get('game_type')
    score = data.get('score')
    
    if not telegram_id or not game_id or not game_type or score is None:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Validate game type
    valid_games = ["stellar_tap", "cosmic_swipe", "asteroid_field", "nebula_puzzle"]
    if game_type not in valid_games:
        return jsonify({"error": "Invalid mini-game type"}), 400
    
    # Calculate reward based on score and game type
    max_reward = calculate_max_mini_game_reward(user, game_type)
    
    # Score should be between 0 and 100 (percentage of success)
    score = max(0, min(100, score))
    reward = (score / 100) * max_reward
    
    # Apply power-up bonuses for mini-games
    for power_up in user.power_ups:
        if power_up.is_active and power_up.type == "mini_game_boost":
            reward *= power_up.multiplier
    
    # Apply storage limits
    if user.equipment:
        max_storage = user.equipment.storage_capacity
        new_balance = min(user.stardust_balance + reward, max_storage)
        stardust_gained = new_balance - user.stardust_balance
    else:
        new_balance = user.stardust_balance + reward
        stardust_gained = reward
    
    # Update user balance
    user.stardust_balance = new_balance
    
    # Create transaction record
    transaction = Transaction(
        user_id=user.id,
        type="mini_game",
        amount=stardust_gained,
        currency="stardust",
        description=f"{game_type.replace('_', ' ').title()} mini-game reward",
        metadata={
            "game_id": game_id,
            "game_type": game_type,
            "score": score
        }
    )
    db.session.add(transaction)
    
    # Add experience points (1 XP per 2 stardust from mini-games)
    experience_gained = math.floor(stardust_gained / 2)
    user.experience += experience_gained
    
    # Check for level up
    check_level_up(user)
    
    # Update user's last active timestamp
    user.last_active = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Mini-game completed",
        "stardust_gained": stardust_gained,
        "new_balance": user.stardust_balance,
        "experience_gained": experience_gained,
        "level": user.level
    }), 200

# Helper functions

def calculate_mining_rate(user):
    """Calculate the current mining rate for a user"""
    # Base rate from mining stats
    if not user.mining_stats:
        return 1.0
    
    base_rate = user.mining_stats.base_rate
    
    # Equipment multiplier
    equipment_multiplier = 1.0
    if user.equipment:
        equipment_multiplier = user.equipment.drill_efficiency
    
    # Power-up multipliers
    power_up_multiplier = 1.0
    for power_up in user.power_ups:
        if power_up.is_active and power_up.type == "mining_efficiency":
            # Check if power-up is expired
            if power_up.expires_at and power_up.expires_at < datetime.utcnow():
                power_up.deactivate()
                db.session.commit()
                continue
            
            power_up_multiplier *= power_up.multiplier
    
    # Referral bonus (5% per referral up to 25%)
    referral_count = len(user.referrals)
    referral_bonus = 1.0 + (min(referral_count, 5) * 0.05)
    
    # Level bonus (2% per level)
    level_bonus = 1.0 + ((user.level - 1) * 0.02)
    
    # Calculate final rate
    mining_rate = base_rate * equipment_multiplier * power_up_multiplier * referral_bonus * level_bonus
    
    return mining_rate

def check_level_up(user):
    """Check if user has enough experience to level up"""
    # Experience required for next level: level^2 * 100
    next_level_exp = user.level * user.level * 100
    
    if user.experience >= next_level_exp:
        user.level += 1
        
        # Increase base mining rate with level
        if user.mining_stats:
            user.mining_stats.base_rate = 1.0 + ((user.level - 1) * 0.1)  # 10% increase per level
        
        return True
    
    return False

def get_mini_game_config(game_type, user_level):
    """Get configuration for a mini-game based on type and user level"""
    configs = {
        "stellar_tap": {
            "duration": 30,  # seconds
            "target_count": 10 + user_level,  # more targets with higher level
            "speed_multiplier": 1.0 + (user_level * 0.05)  # 5% faster per level
        },
        "cosmic_swipe": {
            "duration": 45,
            "pattern_complexity": 1 + math.floor(user_level / 3),  # more complex patterns at higher levels
            "time_per_pattern": 10 - min(5, math.floor(user_level / 5))  # less time at higher levels
        },
        "asteroid_field": {
            "duration": 60,
            "asteroid_count": 15 + user_level,
            "speed_multiplier": 1.0 + (user_level * 0.04)
        },
        "nebula_puzzle": {
            "duration": 90,
            "grid_size": min(8, 4 + math.floor(user_level / 5)),  # larger grid at higher levels
            "element_types": min(6, 3 + math.floor(user_level / 7))  # more element types at higher levels
        }
    }
    
    return configs.get(game_type, {})

def calculate_max_mini_game_reward(user, game_type):
    """Calculate the maximum possible reward for a mini-game"""
    # Base rewards by game type
    base_rewards = {
        "stellar_tap": 50,
        "cosmic_swipe": 75,
        "asteroid_field": 100,
        "nebula_puzzle": 150
    }
    
    base_reward = base_rewards.get(game_type, 50)
    
    # Scale with user level (10% increase per level)
    level_multiplier = 1.0 + ((user.level - 1) * 0.1)
    
    # Apply mining rate as a smaller factor (square root of mining rate)
    mining_rate = 1.0
    if user.mining_stats:
        mining_rate = user.mining_stats.current_rate
    
    mining_multiplier = math.sqrt(mining_rate)
    
    return base_reward * level_multiplier * mining_multiplier
