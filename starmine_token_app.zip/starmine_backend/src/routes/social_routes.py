from flask import Blueprint, jsonify, request
from src.models.models import User, Referral, Leaderboard
from src.main import db
from datetime import datetime
import uuid
import json

social_bp = Blueprint('social', __name__)

@social_bp.route('/referral/code', methods=['GET'])
def get_referral_code():
    """Get user's referral code"""
    telegram_id = request.args.get('telegram_id')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if user has a referral code
    if not user.referral_code:
        # Generate a new referral code
        referral_code = f"STAR{uuid.uuid4().hex[:6].upper()}"
        user.referral_code = referral_code
        db.session.commit()
    
    return jsonify({
        "referral_code": user.referral_code,
        "referral_count": len(user.referrals),
        "share_url": f"https://t.me/starmine_bot?start={user.referral_code}"
    }), 200

@social_bp.route('/referral/use', methods=['POST'])
def use_referral_code():
    """Use a referral code"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    referral_code = data.get('referral_code')
    
    if not telegram_id or not referral_code:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if user already has a referrer
    if user.referred_by:
        return jsonify({"error": "User already has a referrer"}), 400
    
    # Find referrer
    referrer = User.query.filter_by(referral_code=referral_code).first()
    if not referrer:
        return jsonify({"error": "Invalid referral code"}), 404
    
    # Check if user is trying to refer themselves
    if user.id == referrer.id:
        return jsonify({"error": "Cannot refer yourself"}), 400
    
    # Set referrer
    user.referred_by = referral_code
    
    # Create referral record
    referral = Referral(
        referrer_id=referrer.id,
        referred_id=user.id
    )
    db.session.add(referral)
    
    # Award referral bonus to referrer
    referrer.stardust_balance += 500  # 500 stardust bonus
    
    # Create transaction record for referrer
    from src.models.models import Transaction
    transaction = Transaction(
        user_id=referrer.id,
        type="referral",
        amount=500,
        currency="stardust",
        description="Referral bonus",
        metadata={
            "referred_id": user.id,
            "referred_telegram_id": telegram_id
        }
    )
    db.session.add(transaction)
    
    # Update user's and referrer's last active timestamp
    user.last_active = datetime.utcnow()
    referrer.last_active = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Referral code used successfully",
        "referrer_name": referrer.username or referrer.first_name
    }), 200

@social_bp.route('/referral/stats', methods=['GET'])
def get_referral_stats():
    """Get user's referral statistics"""
    telegram_id = request.args.get('telegram_id')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Get referrals
    referrals = Referral.query.filter_by(referrer_id=user.id).all()
    
    # Get referred users
    referred_users = []
    for referral in referrals:
        referred_user = User.query.filter_by(id=referral.referred_id).first()
        if referred_user:
            referred_users.append({
                "id": referred_user.id,
                "username": referred_user.username,
                "first_name": referred_user.first_name,
                "last_name": referred_user.last_name,
                "level": referred_user.level,
                "date_referred": referral.date_referred.isoformat() if referral.date_referred else None,
                "bonus_claimed": referral.bonus_claimed
            })
    
    # Calculate mining boost from referrals
    referral_count = len(referrals)
    mining_boost = min(referral_count * 0.05, 0.25)  # 5% per referral, max 25%
    
    return jsonify({
        "referral_code": user.referral_code,
        "referral_count": referral_count,
        "mining_boost": mining_boost,
        "referred_users": referred_users,
        "share_url": f"https://t.me/starmine_bot?start={user.referral_code}"
    }), 200

@social_bp.route('/leaderboard/global', methods=['GET'])
def get_global_leaderboard():
    """Get global leaderboard"""
    leaderboard_type = request.args.get('type', 'stardust')
    limit = request.args.get('limit', 10, type=int)
    
    # Get user's telegram_id for highlighting their position
    telegram_id = request.args.get('telegram_id')
    user_id = None
    
    if telegram_id:
        user = User.query.filter_by(telegram_id=telegram_id).first()
        if user:
            user_id = user.id
    
    # Get leaderboard entries
    if leaderboard_type == 'stardust':
        # For stardust leaderboard, we'll use the stardust_balance directly
        users = User.query.order_by(User.stardust_balance.desc()).limit(limit).all()
        
        leaderboard = []
        for i, user in enumerate(users):
            leaderboard.append({
                "rank": i + 1,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "level": user.level,
                "score": user.stardust_balance,
                "is_current_user": user.id == user_id
            })
        
        # If user is not in top results, add their position
        if user_id and not any(entry["user_id"] == user_id for entry in leaderboard):
            user = User.query.filter_by(id=user_id).first()
            if user:
                # Count users with higher stardust balance
                rank = User.query.filter(User.stardust_balance > user.stardust_balance).count() + 1
                
                leaderboard.append({
                    "rank": rank,
                    "user_id": user.id,
                    "username": user.username,
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                    "level": user.level,
                    "score": user.stardust_balance,
                    "is_current_user": True
                })
    
    elif leaderboard_type == 'level':
        # For level leaderboard, we'll order by level and then by experience
        users = User.query.order_by(User.level.desc(), User.experience.desc()).limit(limit).all()
        
        leaderboard = []
        for i, user in enumerate(users):
            leaderboard.append({
                "rank": i + 1,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "level": user.level,
                "score": user.level,
                "experience": user.experience,
                "is_current_user": user.id == user_id
            })
        
        # If user is not in top results, add their position
        if user_id and not any(entry["user_id"] == user_id for entry in leaderboard):
            user = User.query.filter_by(id=user_id).first()
            if user:
                # Count users with higher level or same level but higher experience
                rank = User.query.filter(
                    (User.level > user.level) | 
                    ((User.level == user.level) & (User.experience > user.experience))
                ).count() + 1
                
                leaderboard.append({
                    "rank": rank,
                    "user_id": user.id,
                    "username": user.username,
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                    "level": user.level,
                    "score": user.level,
                    "experience": user.experience,
                    "is_current_user": True
                })
    
    elif leaderboard_type == 'referrals':
        # For referral leaderboard, we'll count the number of referrals
        # This is a more complex query that would typically use a subquery or join
        # For simplicity, we'll use a less efficient approach here
        users = User.query.all()
        user_referrals = []
        
        for user in users:
            referral_count = Referral.query.filter_by(referrer_id=user.id).count()
            user_referrals.append((user, referral_count))
        
        # Sort by referral count
        user_referrals.sort(key=lambda x: x[1], reverse=True)
        
        # Take top results
        top_users = user_referrals[:limit]
        
        leaderboard = []
        for i, (user, referral_count) in enumerate(top_users):
            leaderboard.append({
                "rank": i + 1,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "level": user.level,
                "score": referral_count,
                "is_current_user": user.id == user_id
            })
        
        # If user is not in top results, add their position
        if user_id and not any(entry["user_id"] == user_id for entry in leaderboard):
            user = User.query.filter_by(id=user_id).first()
            if user:
                user_referral_count = Referral.query.filter_by(referrer_id=user.id).count()
                
                # Count users with higher referral count
                rank = sum(1 for _, count in user_referrals if count > user_referral_count) + 1
                
                leaderboard.append({
                    "rank": rank,
                    "user_id": user.id,
                    "username": user.username,
                    "first_name": user.first_name,
                    "last_name": user.last_name,
                    "level": user.level,
                    "score": user_referral_count,
                    "is_current_user": True
                })
    
    else:
        return jsonify({"error": "Invalid leaderboard type"}), 400
    
    return jsonify({
        "type": leaderboard_type,
        "entries": leaderboard
    }), 200

@social_bp.route('/leaderboard/friends', methods=['GET'])
def get_friends_leaderboard():
    """Get leaderboard of user's friends (referrals and referrer)"""
    telegram_id = request.args.get('telegram_id')
    leaderboard_type = request.args.get('type', 'stardust')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Get user's referrals
    referrals = Referral.query.filter_by(referrer_id=user.id).all()
    referred_user_ids = [referral.referred_id for referral in referrals]
    
    # Get user's referrer
    referrer_id = None
    if user.referred_by:
        referrer = User.query.filter_by(referral_code=user.referred_by).first()
        if referrer:
            referrer_id = referrer.id
    
    # Combine user, referrals, and referrer
    friend_ids = [user.id] + referred_user_ids
    if referrer_id:
        friend_ids.append(referrer_id)
    
    # Get friends' data
    friends = User.query.filter(User.id.in_(friend_ids)).all()
    
    # Create leaderboard based on type
    if leaderboard_type == 'stardust':
        # Sort by stardust balance
        friends.sort(key=lambda x: x.stardust_balance, reverse=True)
        
        leaderboard = []
        for i, friend in enumerate(friends):
            leaderboard.append({
                "rank": i + 1,
                "user_id": friend.id,
                "username": friend.username,
                "first_name": friend.first_name,
                "last_name": friend.last_name,
                "level": friend.level,
                "score": friend.stardust_balance,
                "is_current_user": friend.id == user.id,
                "is_referrer": friend.id == referrer_id,
                "is_referral": friend.id in referred_user_ids
            })
    
    elif leaderboard_type == 'level':
        # Sort by level and then by experience
        friends.sort(key=lambda x: (x.level, x.experience), reverse=True)
        
        leaderboard = []
        for i, friend in enumerate(friends):
            leaderboard.append({
                "rank": i + 1,
                "user_id": friend.id,
                "username": friend.username,
                "first_name": friend.first_name,
                "last_name": friend.last_name,
                "level": friend.level,
                "score": friend.level,
                "experience": friend.experience,
                "is_current_user": friend.id == user.id,
                "is_referrer": friend.id == referrer_id,
                "is_referral": friend.id in referred_user_ids
            })
    
    else:
        return jsonify({"error": "Invalid leaderboard type"}), 400
    
    return jsonify({
        "type": leaderboard_type,
        "entries": leaderboard
    }), 200

@social_bp.route('/quests/daily', methods=['GET'])
def get_daily_quests():
    """Get daily quests for user"""
    telegram_id = request.args.get('telegram_id')
    
    if not telegram_id:
        return jsonify({"error": "Missing telegram_id parameter"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # In a real app, quests would be stored in the database and generated daily
    # For this demo, we'll return static quests
    
    # Calculate quest progress based on user activity
    from src.models.models import MiningSession, Transaction
    
    # Mining quest progress
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    mining_sessions = MiningSession.query.filter(
        MiningSession.user_id == user.id,
        MiningSession.start_time >= today_start,
        MiningSession.completed == True
    ).all()
    
    total_mined_today = sum(session.stardust_mined for session in mining_sessions)
    
    # Mini-game quest progress
    mini_game_transactions = Transaction.query.filter(
        Transaction.user_id == user.id,
        Transaction.type == "mini_game",
        Transaction.timestamp >= today_start
    ).count()
    
    # Referral quest progress
    referrals_today = Referral.query.filter(
        Referral.referrer_id == user.id,
        Referral.date_referred >= today_start
    ).count()
    
    # Login streak
    # In a real app, this would be tracked in the database
    # For this demo, we'll assume the user has a streak of 3 days
    login_streak = 3
    
    quests = [
        {
            "id": "daily_mining",
            "title": "Mine 500 Stardust",
            "description": "Mine a total of 500 stardust today",
            "progress": min(total_mined_today, 500),
            "target": 500,
            "completed": total_mined_today >= 500,
            "reward": {
                "amount": 100,
                "currency": "stardust"
            }
        },
        {
            "id": "play_mini_games",
            "title": "Play 3 Mini-Games",
            "description": "Complete 3 mini-games today",
            "progress": mini_game_transactions,
            "target": 3,
            "completed": mini_game_transactions >= 3,
            "reward": {
                "amount": 150,
                "currency": "stardust"
            }
        },
        {
            "id": "invite_friend",
            "title": "Invite a Friend",
            "description": "Invite a new friend to StarMine",
            "progress": referrals_today,
            "target": 1,
            "completed": referrals_today >= 1,
            "reward": {
                "amount": 2,
                "currency": "stellar_crystals"
            }
        },
        {
            "id": "login_streak",
            "title": "Daily Login",
            "description": "Log in to StarMine",
            "progress": 1,
            "target": 1,
            "completed": True,
            "reward": {
                "amount": 50,
                "currency": "stardust"
            },
            "streak": login_streak,
            "streak_bonus": login_streak * 10  # 10 stardust per day in streak
        }
    ]
    
    # Calculate time until reset
    now = datetime.utcnow()
    tomorrow = now.replace(hour=0, minute=0, second=0, microsecond=0)
    tomorrow = tomorrow.replace(day=tomorrow.day + 1)
    seconds_until_reset = (tomorrow - now).total_seconds()
    
    return jsonify({
        "quests": quests,
        "reset_in_seconds": seconds_until_reset,
        "streak": login_streak
    }), 200

@social_bp.route('/quests/claim', methods=['POST'])
def claim_quest_reward():
    """Claim reward for completed quest"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    quest_id = data.get('quest_id')
    
    if not telegram_id or not quest_id:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # In a real app, quest completion would be verified against the database
    # For this demo, we'll simulate quest completion and rewards
    
    # Define quest rewards
    quest_rewards = {
        "daily_mining": {"amount": 100, "currency": "stardust"},
        "play_mini_games": {"amount": 150, "currency": "stardust"},
        "invite_friend": {"amount": 2, "currency": "stellar_crystals"},
        "login_streak": {"amount": 50, "currency": "stardust", "streak_bonus": 10}  # 10 per day in streak
    }
    
    if quest_id not in quest_rewards:
        return jsonify({"error": "Invalid quest ID"}), 400
    
    reward = quest_rewards[quest_id]
    
    # Apply reward
    if reward["currency"] == "stardust":
        amount = reward["amount"]
        
        # Add streak bonus for login quest
        if quest_id == "login_streak":
            # In a real app, the streak would be fetched from the database
            streak = 3  # Simulated streak
            amount += reward["streak_bonus"] * streak
        
        user.stardust_balance += amount
        
        # Create transaction record
        from src.models.models import Transaction
        transaction = Transaction(
            user_id=user.id,
            type="quest_reward",
            amount=amount,
            currency="stardust",
            description=f"Quest reward: {quest_id}",
            metadata={
                "quest_id": quest_id
            }
        )
        db.session.add(transaction)
        
        result = {
            "success": True,
            "reward": {
                "amount": amount,
                "currency": "stardust"
            },
            "new_balance": user.stardust_balance
        }
    
    elif reward["currency"] == "stellar_crystals":
        amount = reward["amount"]
        user.stellar_crystals += amount
        
        # Create transaction record
        from src.models.models import Transaction
        transaction = Transaction(
            user_id=user.id,
            type="quest_reward",
            amount=amount,
            currency="stellar_crystals",
            description=f"Quest reward: {quest_id}",
            metadata={
                "quest_id": quest_id
            }
        )
        db.session.add(transaction)
        
        result = {
            "success": True,
            "reward": {
                "amount": amount,
                "currency": "stellar_crystals"
            },
            "new_balance": user.stellar_crystals
        }
    
    else:
        return jsonify({"error": "Invalid reward currency"}), 500
    
    # Update user's last active timestamp
    user.last_active = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify(result), 200
