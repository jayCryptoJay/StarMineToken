from flask import Blueprint, jsonify, request
from src.models.models import User, Transaction
from src.main import db
from datetime import datetime
import uuid
import json
import os

store_bp = Blueprint('store', __name__)

@store_bp.route('/power-ups', methods=['GET'])
def get_power_ups():
    """Get available power-ups for purchase"""
    # Define available power-ups
    power_ups = [
        {
            "id": "stardust_magnet",
            "name": "Stardust Magnet",
            "description": "+25% mining rate for 4 hours",
            "type": "mining_efficiency",
            "multiplier": 1.25,
            "duration": 14400,  # 4 hours in seconds
            "price": {
                "amount": 200,
                "currency": "stardust"
            }
        },
        {
            "id": "energy_amplifier",
            "name": "Energy Amplifier",
            "description": "Reduces energy consumption by 20%",
            "type": "energy_efficiency",
            "multiplier": 1.2,
            "duration": 21600,  # 6 hours in seconds
            "price": {
                "amount": 250,
                "currency": "stardust"
            }
        },
        {
            "id": "temporal_accelerator",
            "name": "Temporal Accelerator",
            "description": "+50% mining speed for 2 hours",
            "type": "time_accelerator",
            "multiplier": 1.5,
            "duration": 7200,  # 2 hours in seconds
            "price": {
                "amount": 300,
                "currency": "stardust"
            }
        },
        {
            "id": "cooldown_nullifier",
            "name": "Cooldown Nullifier",
            "description": "Skip cooldown period once",
            "type": "cooldown_nullifier",
            "multiplier": 1.0,
            "duration": 0,  # Instant effect
            "price": {
                "amount": 5,
                "currency": "stellar_crystals"
            }
        },
        {
            "id": "supernova_surge",
            "name": "Supernova Surge",
            "description": "5x mining rate for 30 minutes",
            "type": "mining_efficiency",
            "multiplier": 5.0,
            "duration": 1800,  # 30 minutes in seconds
            "price": {
                "amount": 15,
                "currency": "stellar_crystals"
            }
        },
        {
            "id": "cosmic_harmony",
            "name": "Cosmic Harmony",
            "description": "All power-ups active simultaneously for 1 hour",
            "type": "special",
            "multiplier": 2.0,
            "duration": 3600,  # 1 hour in seconds
            "price": {
                "amount": 25,
                "currency": "stellar_crystals"
            }
        }
    ]
    
    return jsonify(power_ups), 200

@store_bp.route('/purchase', methods=['POST'])
def purchase_item():
    """Purchase a power-up or equipment upgrade"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    item_type = data.get('item_type')
    item_id = data.get('item_id')
    currency = data.get('currency')
    
    if not telegram_id or not item_type or not item_id or not currency:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Get available power-ups
    if item_type == 'power_up':
        # This would normally be fetched from a database
        power_ups = {
            "mining_efficiency": {
                "name": "Stardust Magnet",
                "type": "mining_efficiency",
                "multiplier": 1.25,
                "duration": 14400,  # 4 hours in seconds
                "price": {
                    "amount": 200,
                    "currency": "stardust"
                }
            },
            "time_accelerator": {
                "name": "Temporal Accelerator",
                "type": "time_accelerator",
                "multiplier": 1.5,
                "duration": 7200,  # 2 hours in seconds
                "price": {
                    "amount": 300,
                    "currency": "stardust"
                }
            },
            "cooldown_nullifier": {
                "name": "Cooldown Nullifier",
                "type": "cooldown_nullifier",
                "multiplier": 1.0,
                "duration": 0,  # Instant effect
                "price": {
                    "amount": 5,
                    "currency": "stellar_crystals"
                }
            },
            "supernova_surge": {
                "name": "Supernova Surge",
                "type": "mining_efficiency",
                "multiplier": 5.0,
                "duration": 1800,  # 30 minutes in seconds
                "price": {
                    "amount": 15,
                    "currency": "stellar_crystals"
                }
            }
        }
        
        # Check if power-up exists
        if item_id not in power_ups:
            return jsonify({"error": "Power-up not found"}), 404
        
        power_up = power_ups[item_id]
        
        # Check if currency matches
        if power_up["price"]["currency"] != currency:
            return jsonify({"error": "Invalid currency for this power-up"}), 400
        
        # Check if user has enough currency
        if currency == "stardust" and user.stardust_balance < power_up["price"]["amount"]:
            return jsonify({"error": "Not enough stardust"}), 400
        
        if currency == "stellar_crystals" and user.stellar_crystals < power_up["price"]["amount"]:
            return jsonify({"error": "Not enough stellar crystals"}), 400
        
        # Deduct currency
        if currency == "stardust":
            user.stardust_balance -= power_up["price"]["amount"]
        elif currency == "stellar_crystals":
            user.stellar_crystals -= power_up["price"]["amount"]
        
        # Create power-up in user's inventory
        from src.models.models import PowerUp
        new_power_up = PowerUp(
            user_id=user.id,
            type=power_up["type"],
            name=power_up["name"],
            multiplier=power_up["multiplier"],
            duration=power_up["duration"]
        )
        db.session.add(new_power_up)
        
        # Create transaction record
        transaction = Transaction(
            user_id=user.id,
            type="purchase",
            amount=-power_up["price"]["amount"],
            currency=currency,
            description=f"Purchased {power_up['name']}",
            metadata={
                "item_type": "power_up",
                "item_id": item_id
            }
        )
        db.session.add(transaction)
        
        # Update user's last active timestamp
        user.last_active = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"Successfully purchased {power_up['name']}",
            "new_stardust_balance": user.stardust_balance if currency == "stardust" else None,
            "new_stellar_crystals": user.stellar_crystals if currency == "stellar_crystals" else None,
            "power_up": new_power_up.to_dict()
        }), 200
    
    # Handle equipment upgrades
    elif item_type == 'equipment':
        # This would normally be fetched from a database
        equipment_upgrades = {
            "drill": {
                "price": {
                    "amount": lambda level: 500 * level,
                    "currency": "stardust"
                }
            },
            "storage": {
                "price": {
                    "amount": lambda level: 400 * level,
                    "currency": "stardust"
                }
            },
            "energy": {
                "price": {
                    "amount": lambda level: 600 * level,
                    "currency": "stardust"
                }
            }
        }
        
        # Check if equipment type exists
        if item_id not in equipment_upgrades:
            return jsonify({"error": "Equipment type not found"}), 404
        
        # Check if user has equipment
        if not user.equipment:
            return jsonify({"error": "User has no equipment"}), 400
        
        # Get current level and calculate price
        current_level = getattr(user.equipment, f"{item_id}_level")
        price_func = equipment_upgrades[item_id]["price"]["amount"]
        price = price_func(current_level)
        
        # Check if currency matches
        if equipment_upgrades[item_id]["price"]["currency"] != currency:
            return jsonify({"error": "Invalid currency for this upgrade"}), 400
        
        # Check if user has enough currency
        if currency == "stardust" and user.stardust_balance < price:
            return jsonify({"error": "Not enough stardust"}), 400
        
        # Deduct currency
        user.stardust_balance -= price
        
        # Upgrade equipment
        if item_id == "drill":
            user.equipment.upgrade_drill()
        elif item_id == "storage":
            user.equipment.upgrade_storage()
        elif item_id == "energy":
            user.equipment.upgrade_energy()
        
        # Create transaction record
        transaction = Transaction(
            user_id=user.id,
            type="upgrade",
            amount=-price,
            currency=currency,
            description=f"Upgraded {item_id} to level {getattr(user.equipment, f'{item_id}_level')}",
            metadata={
                "item_type": "equipment",
                "item_id": item_id,
                "new_level": getattr(user.equipment, f"{item_id}_level")
            }
        )
        db.session.add(transaction)
        
        # Update user's last active timestamp
        user.last_active = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"Successfully upgraded {item_id}",
            "new_stardust_balance": user.stardust_balance,
            "equipment": user.equipment.to_dict()
        }), 200
    
    # Handle stellar crystals purchase with TON
    elif item_type == 'stellar_crystals':
        # This would be handled by the create-invoice endpoint
        return jsonify({"error": "TON purchases must use the create-invoice endpoint"}), 400
    
    else:
        return jsonify({"error": "Invalid item type"}), 400

@store_bp.route('/upgrade-equipment', methods=['POST'])
def upgrade_equipment():
    """Upgrade user equipment"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    equipment_type = data.get('equipment_type')
    
    if not telegram_id or not equipment_type:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Check if user has equipment
    if not user.equipment:
        return jsonify({"error": "User has no equipment"}), 400
    
    # Check if equipment type is valid
    if equipment_type not in ["drill", "storage", "energy"]:
        return jsonify({"error": "Invalid equipment type"}), 400
    
    # Calculate upgrade cost
    cost_multipliers = {
        "drill": 500,
        "storage": 400,
        "energy": 600
    }
    
    current_level = getattr(user.equipment, f"{equipment_type}_level")
    cost = cost_multipliers[equipment_type] * current_level
    
    # Check if user has enough stardust
    if user.stardust_balance < cost:
        return jsonify({"error": "Not enough stardust"}), 400
    
    # Deduct stardust
    user.stardust_balance -= cost
    
    # Upgrade equipment
    if equipment_type == "drill":
        user.equipment.upgrade_drill()
    elif equipment_type == "storage":
        user.equipment.upgrade_storage()
    elif equipment_type == "energy":
        user.equipment.upgrade_energy()
    
    # Create transaction record
    transaction = Transaction(
        user_id=user.id,
        type="upgrade",
        amount=-cost,
        currency="stardust",
        description=f"Upgraded {equipment_type} to level {getattr(user.equipment, f'{equipment_type}_level')}",
        metadata={
            "item_type": "equipment",
            "item_id": equipment_type,
            "new_level": getattr(user.equipment, f"{equipment_type}_level")
        }
    )
    db.session.add(transaction)
    
    # Update user's last active timestamp
    user.last_active = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": f"Successfully upgraded {equipment_type}",
        "new_stardust_balance": user.stardust_balance,
        "equipment": user.equipment.to_dict()
    }), 200

@store_bp.route('/create-invoice', methods=['POST'])
def create_invoice():
    """Create a TON payment invoice"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    item_type = data.get('item_type')
    item_id = data.get('item_id')
    amount = data.get('amount')
    
    if not telegram_id or not item_type or not amount:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Generate a unique invoice ID
    invoice_id = str(uuid.uuid4())
    
    # In a real app, this would create an actual TON invoice
    # For this demo, we'll simulate it
    
    # Define TON to Stellar Crystal conversion rates
    crystal_packages = {
        "10": {"ton_amount": 1, "crystals": 10},
        "50": {"ton_amount": 4.5, "crystals": 50},
        "100": {"ton_amount": 8, "crystals": 100}
    }
    
    # For power-ups purchased with TON
    power_up_prices = {
        "premium_drill": {"ton_amount": 5, "name": "Premium Drill"},
        "quantum_storage": {"ton_amount": 7, "name": "Quantum Storage"}
    }
    
    # Determine the TON amount and description
    ton_amount = 0
    description = ""
    
    if item_type == "stellar_crystals":
        if item_id in crystal_packages:
            ton_amount = crystal_packages[item_id]["ton_amount"]
            crystals = crystal_packages[item_id]["crystals"]
            description = f"{crystals} Stellar Crystals"
        else:
            # Custom amount
            ton_amount = amount
            crystals = int(amount * 10)  # 1 TON = 10 Crystals
            description = f"{crystals} Stellar Crystals"
    elif item_type == "power_up" and item_id in power_up_prices:
        ton_amount = power_up_prices[item_id]["ton_amount"]
        description = power_up_prices[item_id]["name"]
    else:
        return jsonify({"error": "Invalid item type or ID"}), 400
    
    # In a real app, this would call the Telegram Bot API to create an invoice
    # For this demo, we'll simulate the URL
    invoice_url = f"https://t.me/wallet?startapp=starmine_pay_{invoice_id}"
    
    # Store the invoice details (in a real app, this would be in a database)
    # For this demo, we'll create a transaction record with pending status
    transaction = Transaction(
        user_id=user.id,
        type="invoice",
        amount=ton_amount,
        currency="ton",
        description=f"Invoice for {description}",
        metadata={
            "invoice_id": invoice_id,
            "item_type": item_type,
            "item_id": item_id,
            "status": "pending"
        }
    )
    db.session.add(transaction)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "invoice_id": invoice_id,
        "invoice_url": invoice_url,
        "ton_amount": ton_amount,
        "description": description
    }), 200

@store_bp.route('/verify-payment', methods=['POST'])
def verify_payment():
    """Verify a TON payment"""
    data = request.get_json()
    telegram_id = data.get('telegram_id')
    invoice_id = data.get('invoice_id')
    
    if not telegram_id or not invoice_id:
        return jsonify({"error": "Missing required parameters"}), 400
    
    # Find user
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Find the invoice transaction
    transaction = Transaction.query.filter(
        Transaction.user_id == user.id,
        Transaction.type == "invoice",
        Transaction.metadata.like(f'%"invoice_id": "{invoice_id}"%')
    ).first()
    
    if not transaction:
        return jsonify({"error": "Invoice not found"}), 404
    
    # Parse metadata
    metadata = json.loads(transaction.metadata) if transaction.metadata else {}
    
    # Check if already processed
    if metadata.get("status") == "completed":
        return jsonify({"error": "Invoice already processed"}), 400
    
    # In a real app, this would verify the payment with the TON blockchain
    # For this demo, we'll simulate a successful payment
    
    # Update transaction status
    metadata["status"] = "completed"
    transaction.metadata = json.dumps(metadata)
    
    # Process the purchase based on item type
    item_type = metadata.get("item_type")
    item_id = metadata.get("item_id")
    
    if item_type == "stellar_crystals":
        # Add stellar crystals to user account
        if item_id in ["10", "50", "100"]:
            crystals = int(item_id)
        else:
            # Custom amount - 1 TON = 10 Crystals
            crystals = int(transaction.amount * 10)
        
        user.stellar_crystals += crystals
        
        # Create a purchase transaction
        purchase_transaction = Transaction(
            user_id=user.id,
            type="purchase",
            amount=crystals,
            currency="stellar_crystals",
            description=f"Purchased {crystals} Stellar Crystals with TON",
            metadata={
                "invoice_id": invoice_id,
                "ton_amount": transaction.amount
            }
        )
        db.session.add(purchase_transaction)
        
        result = {
            "success": True,
            "item_type": "stellar_crystals",
            "amount": crystals,
            "new_balance": user.stellar_crystals
        }
    
    elif item_type == "power_up":
        # Add power-up to user inventory
        power_up_details = {
            "premium_drill": {
                "name": "Premium Drill",
                "type": "mining_efficiency",
                "multiplier": 2.0,
                "duration": 86400  # 24 hours
            },
            "quantum_storage": {
                "name": "Quantum Storage",
                "type": "storage_boost",
                "multiplier": 3.0,
                "duration": 86400  # 24 hours
            }
        }
        
        if item_id in power_up_details:
            details = power_up_details[item_id]
            
            # Create power-up
            from src.models.models import PowerUp
            power_up = PowerUp(
                user_id=user.id,
                type=details["type"],
                name=details["name"],
                multiplier=details["multiplier"],
                duration=details["duration"]
            )
            db.session.add(power_up)
            
            result = {
                "success": True,
                "item_type": "power_up",
                "power_up": power_up.to_dict()
            }
        else:
            result = {
                "success": False,
                "error": "Invalid power-up ID"
            }
    
    else:
        result = {
            "success": False,
            "error": "Invalid item type"
        }
    
    # Update user's last active timestamp
    user.last_active = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify(result), 200
