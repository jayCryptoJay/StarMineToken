import React, { useState, useEffect } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Progress } from './components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import './App.css';

// Mock Telegram WebApp SDK for development
const tg = window.Telegram?.WebApp || {
  initDataUnsafe: {
    user: {
      id: '123456789',
      username: 'testuser',
      first_name: 'Test',
      last_name: 'User'
    }
  },
  ready: () => console.log('Telegram WebApp ready'),
  MainButton: {
    text: '',
    isVisible: false,
    setText: (text) => {
      console.log('Set MainButton text:', text);
      tg.MainButton.text = text;
    },
    show: () => {
      console.log('Show MainButton');
      tg.MainButton.isVisible = true;
    },
    hide: () => {
      console.log('Hide MainButton');
      tg.MainButton.isVisible = false;
    },
    onClick: (callback) => {
      console.log('Set MainButton onClick');
      tg.MainButton.callback = callback;
    }
  },
  onEvent: (eventName, callback) => {
    console.log(`Set ${eventName} event handler`);
  },
  expand: () => console.log('Expand WebApp'),
  close: () => console.log('Close WebApp')
};

function App() {
  const [user, setUser] = useState(null);
  const [miningStatus, setMiningStatus] = useState('idle');
  const [miningProgress, setMiningProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [stardustBalance, setStardustBalance] = useState(0);
  const [miningRate, setMiningRate] = useState(1.0);
  const [estimatedStardust, setEstimatedStardust] = useState(0);
  const [activeTab, setActiveTab] = useState('mine');
  const [powerUps, setPowerUps] = useState([]);
  const [equipment, setEquipment] = useState({
    drill: { level: 1, efficiency: 1.0 },
    storage: { level: 1, capacity: 1000 },
    energy: { level: 1, duration: 14400 }
  });
  const [loading, setLoading] = useState(true);
  const [particles, setParticles] = useState([]);

  // Initialize app
  useEffect(() => {
    // Initialize Telegram WebApp
    tg.ready();
    
    // Simulate fetching user data
    setTimeout(() => {
      const userData = {
        id: tg.initDataUnsafe?.user?.id || '123456789',
        username: tg.initDataUnsafe?.user?.username || 'testuser',
        first_name: tg.initDataUnsafe?.user?.first_name || 'Test',
        last_name: tg.initDataUnsafe?.user?.last_name || 'User',
        level: 1,
        experience: 0,
        next_level_exp: 100
      };
      
      setUser(userData);
      setStardustBalance(0);
      setMiningRate(1.0);
      setLoading(false);
      
      // Simulate fetching mining status
      fetchMiningStatus();
      
      // Set up periodic updates
      const intervalId = setInterval(fetchMiningStatus, 5000);
      return () => clearInterval(intervalId);
    }, 1000);
  }, []);

  // Simulate fetching mining status from API
  const fetchMiningStatus = () => {
    // In a real app, this would be an API call
    // For now, we'll simulate the response
    
    if (miningStatus === 'active') {
      // Update progress
      setMiningProgress(prev => Math.min(prev + 2, 100));
      setTimeRemaining(prev => Math.max(prev - 5, 0));
      setEstimatedStardust(prev => prev + (miningRate * 5 / 3600));
      
      // Generate stardust particles
      if (Math.random() > 0.7) {
        generateParticle();
      }
      
      // Check if mining session is complete
      if (miningProgress >= 100) {
        completeMiningSession();
      }
    }
  };

  // Simulate starting a mining session
  const startMining = () => {
    setMiningStatus('active');
    setMiningProgress(0);
    setTimeRemaining(equipment.energy.duration);
    setEstimatedStardust(0);
    
    // Configure main button for collection
    tg.MainButton.setText('Collect Stardust');
    tg.MainButton.show();
    tg.MainButton.onClick(() => {
      if (miningProgress >= 100) {
        completeMiningSession();
      } else {
        // Early collection with penalty
        const confirmEarly = window.confirm('Mining session not complete. Collect early with 25% penalty?');
        if (confirmEarly) {
          completeMiningSession(true);
        }
      }
    });
  };

  // Simulate completing a mining session
  const completeMiningSession = (early = false) => {
    const penalty = early ? 0.75 : 1.0;
    const stardust = estimatedStardust * penalty;
    
    setMiningStatus('cooldown');
    setStardustBalance(prev => prev + stardust);
    setTimeRemaining(3600); // 1 hour cooldown
    setMiningProgress(0);
    setEstimatedStardust(0);
    
    // Hide main button
    tg.MainButton.hide();
    
    // Show reward notification
    alert(`You collected ${stardust.toFixed(2)} stardust!`);
    
    // After cooldown period
    setTimeout(() => {
      setMiningStatus('idle');
      setTimeRemaining(0);
    }, 5000); // Shortened for demo
  };

  // Generate a stardust particle animation
  const generateParticle = () => {
    const newParticle = {
      id: Date.now(),
      x: Math.random() * 80 + 10, // 10-90% of width
      y: Math.random() * 40 + 30, // 30-70% of height
      size: Math.random() * 10 + 5,
      duration: Math.random() * 2000 + 1000
    };
    
    setParticles(prev => [...prev, newParticle]);
    
    // Remove particle after animation
    setTimeout(() => {
      setParticles(prev => prev.filter(p => p.id !== newParticle.id));
    }, newParticle.duration);
  };

  // Format time remaining
  const formatTimeRemaining = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-gray-900 to-blue-950 text-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500 mx-auto mb-4"></div>
          <p className="text-cyan-400">Loading StarMine...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-blue-950 text-white pb-16">
      {/* Header */}
      <header className="p-4 flex items-center justify-between bg-gray-900/50 border-b border-cyan-900/50">
        <div className="flex items-center">
          <img src="/logo.png" alt="StarMine Logo" className="h-8 w-8 mr-2" />
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
            StarMine
          </h1>
        </div>
        <div className="flex items-center">
          <div className="mr-3 text-right">
            <p className="text-xs text-gray-400">Level {user?.level}</p>
            <p className="text-sm font-bold text-cyan-400">{user?.first_name}</p>
          </div>
          <div className="h-8 w-8 rounded-full bg-cyan-900 flex items-center justify-center text-cyan-300 font-bold">
            {user?.first_name?.[0]}
          </div>
        </div>
      </header>

      {/* Resource Bar */}
      <div className="p-4 bg-gray-900/30 flex justify-between items-center">
        <div className="flex items-center">
          <div className="h-6 w-6 mr-2 bg-cyan-500 rounded-full animate-pulse"></div>
          <div>
            <p className="text-xs text-gray-400">Stardust</p>
            <p className="text-sm font-bold">{stardustBalance.toFixed(2)}</p>
          </div>
        </div>
        <div className="flex items-center">
          <div className="h-6 w-6 mr-2 bg-purple-500 rounded-full"></div>
          <div>
            <p className="text-xs text-gray-400">Stellar Crystals</p>
            <p className="text-sm font-bold">0</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="p-4">
        <Tabs defaultValue="mine" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="mine">Mine</TabsTrigger>
            <TabsTrigger value="upgrade">Upgrade</TabsTrigger>
            <TabsTrigger value="shop">Shop</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
          </TabsList>
          
          <TabsContent value="mine" className="space-y-4">
            {/* Mining Dashboard */}
            <Card className="bg-gray-900/50 border-cyan-900/50">
              <CardHeader>
                <CardTitle className="text-center text-cyan-400">Stardust Mining</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative h-48 bg-gray-950 rounded-lg mb-4 overflow-hidden">
                  {/* Mining Animation */}
                  <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxyYWRpYWxHcmFkaWVudCBpZD0iZ3JhZCIgY3g9IjUwJSIgY3k9IjUwJSIgcj0iNTAlIj48c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjMDYyYzZkIiBzdG9wLW9wYWNpdHk9IjAuMyIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzA0MTAyYSIgc3RvcC1vcGFjaXR5PSIwLjkiLz48L3JhZGlhbEdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyYWQpIi8+PC9zdmc+')]"></div>
                  
                  {/* Stardust Particles */}
                  {particles.map(particle => (
                    <div 
                      key={particle.id}
                      className="absolute bg-cyan-400 rounded-full animate-ping opacity-70"
                      style={{
                        left: `${particle.x}%`,
                        top: `${particle.y}%`,
                        width: `${particle.size}px`,
                        height: `${particle.size}px`,
                        animationDuration: `${particle.duration}ms`
                      }}
                    />
                  ))}
                  
                  {/* Mining Equipment */}
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-24">
                    <div className={`w-full h-full bg-[url('/drill.png')] bg-contain bg-no-repeat bg-center ${miningStatus === 'active' ? 'animate-bounce' : ''}`}></div>
                  </div>
                </div>
                
                {/* Mining Status */}
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Status:</span>
                    <span className={`font-bold ${miningStatus === 'active' ? 'text-green-400' : miningStatus === 'cooldown' ? 'text-orange-400' : 'text-gray-400'}`}>
                      {miningStatus === 'active' ? 'Mining' : miningStatus === 'cooldown' ? 'Cooldown' : 'Idle'}
                    </span>
                  </div>
                  
                  {miningStatus !== 'idle' && (
                    <>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Time Remaining:</span>
                        <span className="font-bold">{formatTimeRemaining(timeRemaining)}</span>
                      </div>
                      
                      <div>
                        <Progress value={miningProgress} className="h-2 bg-gray-800" indicatorClassName="bg-gradient-to-r from-cyan-500 to-blue-600" />
                      </div>
                    </>
                  )}
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Mining Rate:</span>
                    <span className="font-bold text-cyan-400">{miningRate.toFixed(2)}/hr</span>
                  </div>
                  
                  {miningStatus === 'active' && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Estimated Yield:</span>
                      <span className="font-bold text-cyan-400">{estimatedStardust.toFixed(2)}</span>
                    </div>
                  )}
                </div>
                
                {/* Mining Controls */}
                {miningStatus === 'idle' && (
                  <Button 
                    className="w-full mt-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                    onClick={startMining}
                  >
                    Start Mining
                  </Button>
                )}
                
                {miningStatus === 'active' && miningProgress < 100 && (
                  <Button 
                    variant="outline" 
                    className="w-full mt-4 border-cyan-500 text-cyan-400 hover:bg-cyan-950"
                    onClick={() => completeMiningSession(true)}
                  >
                    Collect Early (25% Penalty)
                  </Button>
                )}
                
                {miningStatus === 'active' && miningProgress >= 100 && (
                  <Button 
                    className="w-full mt-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                    onClick={() => completeMiningSession()}
                  >
                    Collect Stardust
                  </Button>
                )}
              </CardContent>
            </Card>
            
            {/* Mini-Games */}
            <Card className="bg-gray-900/50 border-cyan-900/50">
              <CardHeader>
                <CardTitle className="text-center text-cyan-400">Mini-Games</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" className="h-20 flex flex-col border-cyan-900 hover:border-cyan-500 hover:bg-cyan-950/30">
                    <span className="text-cyan-400">Stellar Tap</span>
                    <span className="text-xs text-gray-400">Tap falling stars</span>
                  </Button>
                  
                  <Button variant="outline" className="h-20 flex flex-col border-cyan-900 hover:border-cyan-500 hover:bg-cyan-950/30">
                    <span className="text-cyan-400">Cosmic Swipe</span>
                    <span className="text-xs text-gray-400">Trace constellations</span>
                  </Button>
                  
                  <Button variant="outline" className="h-20 flex flex-col border-cyan-900 hover:border-cyan-500 hover:bg-cyan-950/30">
                    <span className="text-cyan-400">Asteroid Field</span>
                    <span className="text-xs text-gray-400">Navigate asteroids</span>
                  </Button>
                  
                  <Button variant="outline" className="h-20 flex flex-col border-cyan-900 hover:border-cyan-500 hover:bg-cyan-950/30">
                    <span className="text-cyan-400">Nebula Puzzle</span>
                    <span className="text-xs text-gray-400">Connect elements</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="upgrade" className="space-y-4">
            {/* Equipment Upgrades */}
            <Card className="bg-gray-900/50 border-cyan-900/50">
              <CardHeader>
                <CardTitle className="text-center text-cyan-400">Equipment Upgrades</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-gray-950/50 p-3 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h3 className="font-bold text-cyan-400">Mining Drill</h3>
                      <p className="text-xs text-gray-400">Level {equipment.drill.level}</p>
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-blue-600">
                      Upgrade
                    </Button>
                  </div>
                  <div className="text-xs text-gray-300">
                    <p>Current: +{((equipment.drill.efficiency - 1) * 100).toFixed(0)}% mining efficiency</p>
                    <p>Next level: +{((equipment.drill.efficiency + 0.1 - 1) * 100).toFixed(0)}% mining efficiency</p>
                    <p className="text-cyan-400 mt-1">Cost: 500 Stardust</p>
                  </div>
                </div>
                
                <div className="bg-gray-950/50 p-3 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h3 className="font-bold text-cyan-400">Storage Unit</h3>
                      <p className="text-xs text-gray-400">Level {equipment.storage.level}</p>
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-blue-600">
                      Upgrade
                    </Button>
                  </div>
                  <div className="text-xs text-gray-300">
                    <p>Current: {equipment.storage.capacity.toFixed(0)} stardust capacity</p>
                    <p>Next level: {(equipment.storage.capacity * 1.25).toFixed(0)} stardust capacity</p>
                    <p className="text-cyan-400 mt-1">Cost: 400 Stardust</p>
                  </div>
                </div>
                
                <div className="bg-gray-950/50 p-3 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <div>
                      <h3 className="font-bold text-cyan-400">Energy Cell</h3>
                      <p className="text-xs text-gray-400">Level {equipment.energy.level}</p>
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-blue-600">
                      Upgrade
                    </Button>
                  </div>
                  <div className="text-xs text-gray-300">
                    <p>Current: {(equipment.energy.duration / 3600).toFixed(1)} hours mining duration</p>
                    <p>Next level: {((equipment.energy.duration + 3600) / 3600).toFixed(1)} hours mining duration</p>
                    <p className="text-cyan-400 mt-1">Cost: 600 Stardust</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="shop" className="space-y-4">
            {/* Power-up Shop */}
            <Card className="bg-gray-900/50 border-cyan-900/50">
              <CardHeader>
                <CardTitle className="text-center text-cyan-400">Power-Up Shop</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-gray-950/50 p-3 rounded-lg">
                    <h3 className="font-bold text-cyan-400 mb-1">Stardust Magnet</h3>
                    <p className="text-xs text-gray-300 mb-2">+25% mining rate for 4 hours</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-cyan-400">200 Stardust</span>
                      <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-blue-600">
                        Buy
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-gray-950/50 p-3 rounded-lg">
                    <h3 className="font-bold text-cyan-400 mb-1">Temporal Accelerator</h3>
                    <p className="text-xs text-gray-300 mb-2">+50% mining speed for 2 hours</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-cyan-400">300 Stardust</span>
                      <Button size="sm" className="bg-gradient-to-r from-cyan-500 to-blue-600">
                        Buy
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-gray-950/50 p-3 rounded-lg">
                    <h3 className="font-bold text-cyan-400 mb-1">Cooldown Nullifier</h3>
                    <p className="text-xs text-gray-300 mb-2">Skip cooldown period once</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-purple-400">5 Crystals</span>
                      <Button size="sm" className="bg-gradient-to-r from-purple-500 to-indigo-600">
                        Buy
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-gray-950/50 p-3 rounded-lg">
                    <h3 className="font-bold text-cyan-400 mb-1">Supernova Surge</h3>
                    <p className="text-xs text-gray-300 mb-2">5x mining rate for 30 minutes</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-purple-400">15 Crystals</span>
                      <Button size="sm" className="bg-gradient-to-r from-purple-500 to-indigo-600">
                        Buy
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-blue-950/30 rounded-lg border border-blue-900/50">
                  <h3 className="font-bold text-blue-400 mb-1">Premium Currency</h3>
                  <p className="text-xs text-gray-300 mb-2">Purchase Stellar Crystals with TON</p>
                  <div className="grid grid-cols-3 gap-2">
                    <Button size="sm" className="bg-gradient-to-r from-blue-600 to-indigo-700">
                      10 Crystals
                    </Button>
                    <Button size="sm" className="bg-gradient-to-r from-blue-600 to-indigo-700">
                      50 Crystals
                    </Button>
                    <Button size="sm" className="bg-gradient-to-r from-blue-600 to-indigo-700">
                      100 Crystals
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="social" className="space-y-4">
            {/* Social Features */}
            <Card className="bg-gray-900/50 border-cyan-900/50">
              <CardHeader>
                <CardTitle className="text-center text-cyan-400">Referral Program</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-300 mb-3">Invite friends and earn 5% of their mining rate plus bonuses!</p>
                
                <div className="bg-gray-950/50 p-3 rounded-lg mb-3">
                  <p className="text-xs text-gray-400 mb-1">Your Referral Code:</p>
                  <div className="flex">
                    <div className="flex-1 bg-gray-900 p-2 rounded-l-md font-mono text-cyan-400">
                      STAR123
                    </div>
                    <Button className="rounded-l-none bg-gradient-to-r from-cyan-500 to-blue-600">
                      Share
                    </Button>
                  </div>
                </div>
                
                <div className="bg-gray-950/50 p-3 rounded-lg">
                  <h3 className="font-bold text-cyan-400 mb-2">Referral Rewards</h3>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• 500 Stardust when a friend joins</li>
                    <li>• 5 Stellar Crystals when they reach level 5</li>
                    <li>• 5% passive mining boost per active friend</li>
                    <li>• 2% of stardust mined by direct referrals</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/50 border-cyan-900/50">
              <CardHeader>
                <CardTitle className="text-center text-cyan-400">Leaderboard</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center p-2 bg-cyan-900/20 rounded-lg">
                    <div className="w-6 text-center font-bold text-cyan-400">1</div>
                    <div className="w-8 h-8 mx-2 rounded-full bg-cyan-900 flex items-center justify-center text-cyan-300 font-bold">
                      C
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold">CosmicMiner</p>
                      <p className="text-xs text-gray-400">Level 12</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-cyan-400">24,561</p>
                      <p className="text-xs text-gray-400">Stardust</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-2 bg-blue-900/20 rounded-lg">
                    <div className="w-6 text-center font-bold text-blue-400">2</div>
                    <div className="w-8 h-8 mx-2 rounded-full bg-blue-900 flex items-center justify-center text-blue-300 font-bold">
                      S
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold">StarGazer</p>
                      <p className="text-xs text-gray-400">Level 10</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-blue-400">18,932</p>
                      <p className="text-xs text-gray-400">Stardust</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-2 bg-indigo-900/20 rounded-lg">
                    <div className="w-6 text-center font-bold text-indigo-400">3</div>
                    <div className="w-8 h-8 mx-2 rounded-full bg-indigo-900 flex items-center justify-center text-indigo-300 font-bold">
                      N
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold">NebulaHunter</p>
                      <p className="text-xs text-gray-400">Level 9</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-indigo-400">15,784</p>
                      <p className="text-xs text-gray-400">Stardust</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-2 bg-gray-900/30 rounded-lg">
                    <div className="w-6 text-center font-bold text-gray-400">42</div>
                    <div className="w-8 h-8 mx-2 rounded-full bg-cyan-900 flex items-center justify-center text-cyan-300 font-bold">
                      {user?.first_name?.[0]}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold">You</p>
                      <p className="text-xs text-gray-400">Level {user?.level}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-gray-300">{stardustBalance.toFixed(0)}</p>
                      <p className="text-xs text-gray-400">Stardust</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Daily Quests */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-950/90 border-t border-cyan-900/50 p-4">
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-bold text-cyan-400">Daily Quests</h3>
          <p className="text-xs text-gray-400">Resets in 12:34:56</p>
        </div>
        <div className="mt-2 flex space-x-2 overflow-x-auto pb-1">
          <div className="flex-shrink-0 w-40 bg-gray-900/70 p-2 rounded-lg border border-cyan-900/30">
            <p className="text-xs font-bold text-cyan-400">Mine 500 Stardust</p>
            <Progress value={30} className="h-1 mt-1 bg-gray-800" indicatorClassName="bg-cyan-500" />
            <p className="text-xs text-right text-gray-400 mt-1">150/500</p>
          </div>
          <div className="flex-shrink-0 w-40 bg-gray-900/70 p-2 rounded-lg border border-cyan-900/30">
            <p className="text-xs font-bold text-cyan-400">Play 3 Mini-Games</p>
            <Progress value={0} className="h-1 mt-1 bg-gray-800" indicatorClassName="bg-cyan-500" />
            <p className="text-xs text-right text-gray-400 mt-1">0/3</p>
          </div>
          <div className="flex-shrink-0 w-40 bg-gray-900/70 p-2 rounded-lg border border-cyan-900/30">
            <p className="text-xs font-bold text-cyan-400">Invite a Friend</p>
            <Progress value={0} className="h-1 mt-1 bg-gray-800" indicatorClassName="bg-cyan-500" />
            <p className="text-xs text-right text-gray-400 mt-1">0/1</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
