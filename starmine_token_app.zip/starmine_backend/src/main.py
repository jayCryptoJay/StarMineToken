from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import sys
import os
import time
import json
from datetime import datetime, timedelta
import uuid

# Required for deployment
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

app = Flask(__name__)

# Enable database
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'starmine_secret_key')

db = SQLAlchemy(app)

# Import blueprints after db initialization to avoid circular imports
from src.routes.user_routes import user_bp
from src.routes.mining_routes import mining_bp
from src.routes.store_routes import store_bp
from src.routes.social_routes import social_bp

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api/user')
app.register_blueprint(mining_bp, url_prefix='/api/mining')
app.register_blueprint(store_bp, url_prefix='/api/store')
app.register_blueprint(social_bp, url_prefix='/api/social')

@app.route('/')
def index():
    return jsonify({
        "name": "StarMine Token API",
        "version": "1.0.0",
        "status": "online"
    })

@app.route('/api/health')
def health_check():
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "uptime": "unknown"  # Would be implemented with actual server start time
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Not Found",
        "message": "The requested resource was not found"
    }), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({
        "error": "Internal Server Error",
        "message": "An unexpected error occurred"
    }), 500

if __name__ == '__main__':
    # Create tables if they don't exist
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', debug=True)
