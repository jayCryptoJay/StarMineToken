from src.main import db
from datetime import datetime, timedelta
import json

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    telegram_id = db.Column(db.String(50), unique=True, nullable=False)
    username = db.Column(db.String(100), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    last_active = db.Column(db.DateTime, default=datetime.utcnow)
    stardust_balance = db.Column(db.Float, default=0)
    stellar_crystals = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    experience = db.Column(db.Integer, default=0)
    referral_code = db.Column(db.String(20), unique=True, nullable=False)
    referred_by = db.Column(db.String(20), nullable=True)
    
    # Relationships
    mining_stats = db.relationship('MiningStats', backref='user', uselist=False, cascade="all, delete-orphan")
    equipment = db.relationship('Equipment', backref='user', uselist=False, cascade="all, delete-orphan")
    power_ups = db.relationship('PowerUp', backref='user', lazy=True, cascade="all, delete-orphan")
    referrals = db.relationship('Referral', backref='referrer', lazy=True, foreign_keys='Referral.referrer_id', cascade="all, delete-orphan")
    
    def __init__(self, telegram_id, username=None, first_name=None, last_name=None, referral_code=None, referred_by=None):
        self.telegram_id = telegram_id
        self.username = username
        self.first_name = first_name
        self.last_name = last_name
        self.referral_code = referral_code
        self.referred_by = referred_by
        
    def to_dict(self):
        return {
            'id': self.id,
            'telegram_id': self.telegram_id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'registration_date': self.registration_date.isoformat() if self.registration_date else None,
            'last_active': self.last_active.isoformat() if self.last_active else None,
            'stardust_balance': self.stardust_balance,
            'stellar_crystals': self.stellar_crystals,
            'level': self.level,
            'experience': self.experience,
            'referral_code': self.referral_code,
            'mining_stats': self.mining_stats.to_dict() if self.mining_stats else None,
            'equipment': self.equipment.to_dict() if self.equipment else None,
            'active_power_ups': [p.to_dict() for p in self.power_ups if p.is_active]
        }

class MiningStats(db.Model):
    __tablename__ = 'mining_stats'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    base_rate = db.Column(db.Float, default=1.0)
    current_rate = db.Column(db.Float, default=1.0)
    session_start = db.Column(db.DateTime, nullable=True)
    session_end = db.Column(db.DateTime, nullable=True)
    cooldown_end = db.Column(db.DateTime, nullable=True)
    total_mined = db.Column(db.Float, default=0)
    last_calculation = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, user_id, base_rate=1.0):
        self.user_id = user_id
        self.base_rate = base_rate
        self.current_rate = base_rate
    
    def to_dict(self):
        return {
            'base_rate': self.base_rate,
            'current_rate': self.current_rate,
            'session_active': self.is_session_active(),
            'session_start': self.session_start.isoformat() if self.session_start else None,
            'session_end': self.session_end.isoformat() if self.session_end else None,
            'cooldown_end': self.cooldown_end.isoformat() if self.cooldown_end else None,
            'total_mined': self.total_mined,
            'cooldown_active': self.is_cooldown_active(),
            'time_remaining': self.get_time_remaining() if self.is_session_active() else 0
        }
    
    def is_session_active(self):
        if not self.session_start or not self.session_end:
            return False
        now = datetime.utcnow()
        return self.session_start <= now <= self.session_end
    
    def is_cooldown_active(self):
        if not self.cooldown_end:
            return False
        now = datetime.utcnow()
        return now <= self.cooldown_end
    
    def get_time_remaining(self):
        if not self.is_session_active():
            return 0
        now = datetime.utcnow()
        return (self.session_end - now).total_seconds()

class Equipment(db.Model):
    __tablename__ = 'equipment'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    drill_level = db.Column(db.Integer, default=1)
    drill_efficiency = db.Column(db.Float, default=1.0)
    storage_level = db.Column(db.Integer, default=1)
    storage_capacity = db.Column(db.Float, default=1000.0)
    energy_level = db.Column(db.Integer, default=1)
    energy_duration = db.Column(db.Integer, default=14400)  # 4 hours in seconds
    
    def __init__(self, user_id):
        self.user_id = user_id
    
    def to_dict(self):
        return {
            'drill': {
                'level': self.drill_level,
                'efficiency': self.drill_efficiency
            },
            'storage': {
                'level': self.storage_level,
                'capacity': self.storage_capacity
            },
            'energy': {
                'level': self.energy_level,
                'duration': self.energy_duration
            }
        }
    
    def upgrade_drill(self):
        self.drill_level += 1
        self.drill_efficiency = 1.0 + (self.drill_level - 1) * 0.1  # 10% increase per level
    
    def upgrade_storage(self):
        self.storage_level += 1
        self.storage_capacity = 1000.0 * (1.0 + (self.storage_level - 1) * 0.25)  # 25% increase per level
    
    def upgrade_energy(self):
        self.energy_level += 1
        self.energy_duration = 14400 + (self.energy_level - 1) * 3600  # +1 hour per level

class PowerUp(db.Model):
    __tablename__ = 'power_ups'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    multiplier = db.Column(db.Float, default=1.0)
    duration = db.Column(db.Integer, nullable=False)  # Duration in seconds
    activated_at = db.Column(db.DateTime, nullable=True)
    expires_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=False)
    
    def __init__(self, user_id, type, name, multiplier, duration):
        self.user_id = user_id
        self.type = type
        self.name = name
        self.multiplier = multiplier
        self.duration = duration
    
    def to_dict(self):
        return {
            'id': self.id,
            'type': self.type,
            'name': self.name,
            'multiplier': self.multiplier,
            'duration': self.duration,
            'activated_at': self.activated_at.isoformat() if self.activated_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'is_active': self.is_active,
            'time_remaining': self.get_time_remaining() if self.is_active else 0
        }
    
    def activate(self):
        now = datetime.utcnow()
        self.activated_at = now
        self.expires_at = now + timedelta(seconds=self.duration)
        self.is_active = True
    
    def deactivate(self):
        self.is_active = False
    
    def get_time_remaining(self):
        if not self.is_active or not self.expires_at:
            return 0
        now = datetime.utcnow()
        if now > self.expires_at:
            self.deactivate()
            return 0
        return (self.expires_at - now).total_seconds()

class Referral(db.Model):
    __tablename__ = 'referrals'
    
    id = db.Column(db.Integer, primary_key=True)
    referrer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    referred_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date_referred = db.Column(db.DateTime, default=datetime.utcnow)
    bonus_claimed = db.Column(db.Boolean, default=False)
    
    def __init__(self, referrer_id, referred_id):
        self.referrer_id = referrer_id
        self.referred_id = referred_id
    
    def to_dict(self):
        return {
            'id': self.id,
            'referrer_id': self.referrer_id,
            'referred_id': self.referred_id,
            'date_referred': self.date_referred.isoformat() if self.date_referred else None,
            'bonus_claimed': self.bonus_claimed
        }

class MiningSession(db.Model):
    __tablename__ = 'mining_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)
    stardust_mined = db.Column(db.Float, default=0)
    average_rate = db.Column(db.Float, default=0)
    completed = db.Column(db.Boolean, default=False)
    
    def __init__(self, user_id, end_time=None):
        self.user_id = user_id
        if end_time:
            self.end_time = end_time
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'stardust_mined': self.stardust_mined,
            'average_rate': self.average_rate,
            'completed': self.completed,
            'duration': (self.end_time - self.start_time).total_seconds() if self.end_time and self.start_time else None
        }
    
    def complete(self, stardust_mined, average_rate):
        self.end_time = datetime.utcnow()
        self.stardust_mined = stardust_mined
        self.average_rate = average_rate
        self.completed = True

class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # purchase, reward, referral, etc.
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(20), nullable=False)  # stardust, stellar_crystals, TON
    description = db.Column(db.String(255), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    metadata = db.Column(db.Text, nullable=True)  # JSON string for additional data
    
    def __init__(self, user_id, type, amount, currency, description=None, metadata=None):
        self.user_id = user_id
        self.type = type
        self.amount = amount
        self.currency = currency
        self.description = description
        self.metadata = json.dumps(metadata) if metadata else None
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'type': self.type,
            'amount': self.amount,
            'currency': self.currency,
            'description': self.description,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'metadata': json.loads(self.metadata) if self.metadata else None
        }

class Leaderboard(db.Model):
    __tablename__ = 'leaderboards'
    
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(50), nullable=False)  # global, weekly, referral, etc.
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    score = db.Column(db.Float, nullable=False)
    rank = db.Column(db.Integer, nullable=True)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, type, user_id, score):
        self.type = type
        self.user_id = user_id
        self.score = score
    
    def to_dict(self):
        return {
            'id': self.id,
            'type': self.type,
            'user_id': self.user_id,
            'score': self.score,
            'rank': self.rank,
            'last_updated': self.last_updated.isoformat() if self.last_updated else None
        }
