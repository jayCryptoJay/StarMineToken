import { useState } from 'react'
import './App.css'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs"
import { Button } from "./components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./components/ui/card"

function App() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-blue-950 text-white">
      {/* Header */}
      <header className="container mx-auto py-8 px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center mb-6 md:mb-0">
            <img src="/logo.png" alt="StarMine Token Logo" className="h-16 w-16 mr-4" />
            <h1 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
              StarMine Token
            </h1>
          </div>
          <div>
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold">
              Launch App
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 md:py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600">
            Mine Stardust in the Cosmos
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-10">
            Embark on a cosmic mining adventure, collect valuable stardust, and earn rewards in this engaging Telegram Mini App.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold text-lg py-6 px-8">
              Start Mining
            </Button>
            <Button variant="outline" className="border-cyan-500 text-cyan-400 hover:bg-cyan-950 font-bold text-lg py-6 px-8">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Overview */}
      <section className="py-16 px-4 bg-black/20">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
            Cosmic Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="bg-gray-900/80 border-cyan-900 hover:border-cyan-500 transition-all">
              <CardHeader>
                <CardTitle className="text-cyan-400">Mining Mechanics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Collect stardust through passive mining and interactive mini-games in 4-24 hour sessions.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/80 border-cyan-900 hover:border-cyan-500 transition-all">
              <CardHeader>
                <CardTitle className="text-cyan-400">Power-Ups</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Enhance your mining with various power-ups purchasable with TON or Stars in Telegram.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/80 border-cyan-900 hover:border-cyan-500 transition-all">
              <CardHeader>
                <CardTitle className="text-cyan-400">Referral System</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Invite friends and earn rewards through our multi-level referral program with ongoing benefits.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/80 border-cyan-900 hover:border-cyan-500 transition-all">
              <CardHeader>
                <CardTitle className="text-cyan-400">Leaderboards & Quests</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Compete on global leaderboards and complete daily quests for valuable rewards and recognition.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Detailed Information Tabs */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
            Explore StarMine
          </h2>
          
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid grid-cols-2 md:grid-cols-5 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="gameplay">Gameplay</TabsTrigger>
              <TabsTrigger value="powerups">Power-Ups</TabsTrigger>
              <TabsTrigger value="referrals">Referrals</TabsTrigger>
              <TabsTrigger value="leaderboards">Leaderboards</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="bg-gray-900/50 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">StarMine Token Overview</h3>
              <p className="text-gray-300 mb-4">
                StarMine is a Telegram Mini App that allows users to mine virtual "stardust" through an engaging combination of idle mining mechanics and interactive mini-games. Players can enhance their mining capabilities through power-ups, form mining crews with friends, participate in competitions, and earn rewards that can be exchanged for airdrops funded by the game's monetization streams.
              </p>
              <p className="text-gray-300 mb-4">
                The game leverages Telegram's native capabilities to create a viral, retention-focused experience that can generate revenue through multiple streams while providing value to players.
              </p>
              <h4 className="text-xl font-bold text-blue-400 mt-6 mb-3">Key Features</h4>
              <ul className="list-disc pl-6 text-gray-300 space-y-2">
                <li>Mining mechanics with passive and active elements</li>
                <li>Time-based sessions encouraging regular returns</li>
                <li>Equipment upgrades and cosmic region exploration</li>
                <li>Interactive mini-games for bonus rewards</li>
                <li>Power-up system with TON and Stars integration</li>
                <li>Multi-level referral system with ongoing rewards</li>
                <li>Competitive leaderboards and daily quests</li>
                <li>Team mining benefits for social play</li>
              </ul>
            </TabsContent>
            
            <TabsContent value="gameplay" className="bg-gray-900/50 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">Mining Mechanics</h3>
              <p className="text-gray-300 mb-4">
                StarMine combines idle mining with interactive elements to create an engaging gameplay experience:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Stardust Collection</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Passive Mining: Automatic collection over time</li>
                      <li>Active Mining: Interactive tapping/swiping mechanics</li>
                      <li>Expedition Mining: Send drones to different cosmic locations</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Mining Sessions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>4-24 hour sessions based on equipment</li>
                      <li>Return to "activate" equipment after session expiry</li>
                      <li>Accumulation slows if not checked within 4 hours</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <h4 className="text-xl font-bold text-blue-400 mt-6 mb-3">Interactive Mini-Games</h4>
              <p className="text-gray-300 mb-4">
                Engage in short mini-games for bonus stardust:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Stellar Tap</h5>
                  <p className="text-gray-300">Rapidly tap falling stars to collect bonus stardust</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Cosmic Swipe</h5>
                  <p className="text-gray-300">Trace constellations to unlock stardust bonuses</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Asteroid Field</h5>
                  <p className="text-gray-300">Navigate through asteroids to reach rich stardust deposits</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Nebula Puzzle</h5>
                  <p className="text-gray-300">Connect cosmic elements to create chain reactions of stardust</p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="powerups" className="bg-gray-900/50 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">Power-Up System</h3>
              <p className="text-gray-300 mb-4">
                Enhance your mining capabilities with various power-ups:
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Mining Efficiency</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Stardust Magnet: Increases collection rate by 25-100%</li>
                      <li>Energy Amplifier: Reduces energy consumption by 20-50%</li>
                      <li>Cosmic Resonator: Increases chance of rare stardust</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Time Manipulation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Temporal Accelerator: Speeds up mining progress</li>
                      <li>Warp Field Generator: Instantly completes current session</li>
                      <li>Cooldown Nullifier: Eliminates session cooldown</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Special Power-Ups</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Supernova Surge: 5x stardust collection for 1 hour</li>
                      <li>Black Hole Collector: Pulls in all regional stardust</li>
                      <li>Cosmic Harmony: All power-ups active simultaneously</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <h4 className="text-xl font-bold text-blue-400 mt-6 mb-3">Purchase Options</h4>
              <p className="text-gray-300 mb-4">
                Power-ups can be purchased using:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Stardust</h5>
                  <p className="text-gray-300">In-game currency earned through mining</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Stellar Crystals</h5>
                  <p className="text-gray-300">Premium currency earned slowly or purchased with TON</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">TON</h5>
                  <p className="text-gray-300">Direct cryptocurrency purchases through Telegram</p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="referrals" className="bg-gray-900/50 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">Referral & Incentive System</h3>
              <p className="text-gray-300 mb-4">
                Grow your mining operation by inviting friends and forming mining crews:
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Referral Mechanics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Unique referral codes for each player</li>
                      <li>Deep link integration with Telegram</li>
                      <li>QR code sharing option</li>
                      <li>Multi-level tracking (up to 3 levels)</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Referrer Rewards</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>500 Stardust when a referred player completes registration</li>
                      <li>5 Stellar Crystals when a referred player reaches level 5</li>
                      <li>5% passive mining boost for each active referred player</li>
                      <li>2% of stardust mined by direct referrals</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <h4 className="text-xl font-bold text-blue-400 mt-6 mb-3">Team Mining Benefits</h4>
              <p className="text-gray-300 mb-4">
                Form mining crews for additional benefits:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Mining Crews</h5>
                  <p className="text-gray-300">Form crews of up to 5 members for collective bonuses</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Crew Bonuses</h5>
                  <p className="text-gray-300">10% mining rate boost when crew members are online simultaneously</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Crew Challenges</h5>
                  <p className="text-gray-300">Special high-reward missions available only to crews</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Crew Leaderboard</h5>
                  <p className="text-gray-300">Special ranking for most productive mining crews</p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="leaderboards" className="bg-gray-900/50 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">Leaderboards & Quest Systems</h3>
              <p className="text-gray-300 mb-4">
                Compete with other miners and complete daily challenges:
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Global Leaderboards</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Stardust Collectors: Total lifetime collection</li>
                      <li>Weekly Mining Champions: Weekly collection</li>
                      <li>Power-up Masters: Efficiency rating</li>
                      <li>Referral Champions: Number of successful referrals</li>
                      <li>Mini-Game Masters: Highest scores in mini-games</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-900/80 border-cyan-900">
                  <CardHeader>
                    <CardTitle className="text-cyan-400">Daily Quest System</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6 text-gray-300 space-y-2">
                      <li>Daily Mining Quests: Collect specific amounts of stardust</li>
                      <li>Social Quests: Invite friends and mine with crew members</li>
                      <li>Mini-Game Quests: Achieve specific scores</li>
                      <li>Exploration Quests: Discover new cosmic regions</li>
                      <li>Streak Rewards: Increasing benefits for consecutive daily play</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
              
              <h4 className="text-xl font-bold text-blue-400 mt-6 mb-3">Reward Structure</h4>
              <p className="text-gray-300 mb-4">
                Earn valuable rewards for your achievements:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Leaderboard Rewards</h5>
                  <p className="text-gray-300">Weekly stardust, Stellar Crystals, and exclusive badges</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Quest Rewards</h5>
                  <p className="text-gray-300">Stardust, power-ups, and equipment upgrades</p>
                </div>
                <div className="bg-gray-900/60 p-4 rounded-lg">
                  <h5 className="font-bold text-cyan-400 mb-2">Streak Bonuses</h5>
                  <p className="text-gray-300">Increasing rewards for consecutive daily quest completion</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-900 to-purple-900">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
            Ready to Start Mining?
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
            Join thousands of miners across the cosmos and start collecting valuable stardust today!
          </p>
          <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold text-lg py-6 px-10">
            Launch StarMine
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <img src="/logo.png" alt="StarMine Token Logo" className="h-10 w-10 mr-3" />
              <span className="text-gray-400">© 2025 StarMine Token. All rights reserved.</span>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-cyan-400">Terms</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400">Privacy</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
