# StarMine Token - Deployment Guide

## Overview

This document provides instructions for deploying the StarMine Token Telegram Mini App. The application consists of two main components:

1. **Backend API**: A Flask application that handles user data, mining mechanics, and game logic
2. **Frontend WebApp**: A React application that integrates with the Telegram WebApp SDK

## Prerequisites

- A server with Ubuntu 20.04 or newer
- Domain name for the backend API
- Telegram Bot created through BotFather
- TON Wallet for testing payments

## Backend Deployment

### Server Setup

1. Update the server and install dependencies:

```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y python3-pip python3-venv nginx certbot python3-certbot-nginx
```

2. Clone the repository:

```bash
git clone https://github.com/yourusername/starmine-token.git
cd starmine-token
```

3. Create and activate a virtual environment:

```bash
python3 -m venv venv
source venv/bin/activate
```

4. Install dependencies:

```bash
pip install -r requirements.txt
```

### Database Setup

1. Install PostgreSQL:

```bash
sudo apt install -y postgresql postgresql-contrib
```

2. Create a database and user:

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE starmine;
CREATE USER starmine_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE starmine TO starmine_user;
\q
```

3. Update the database configuration in `src/main.py`:

```python
app.config['SQLALCHEMY_DATABASE_URI'] = f"postgresql://{os.getenv('DB_USERNAME', 'starmine_user')}:{os.getenv('DB_PASSWORD', 'your_secure_password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '5432')}/{os.getenv('DB_NAME', 'starmine')}"
```

### Environment Configuration

1. Create a `.env` file in the project root:

```
DB_USERNAME=starmine_user
DB_PASSWORD=your_secure_password
DB_HOST=localhost
DB_PORT=5432
DB_NAME=starmine
SECRET_KEY=your_secure_secret_key
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
```

2. Install Gunicorn:

```bash
pip install gunicorn
```

3. Create a systemd service file:

```bash
sudo nano /etc/systemd/system/starmine.service
```

```
[Unit]
Description=StarMine Token API
After=network.target

[Service]
User=ubuntu
Group=www-data
WorkingDirectory=/path/to/starmine-token
Environment="PATH=/path/to/starmine-token/venv/bin"
EnvironmentFile=/path/to/starmine-token/.env
ExecStart=/path/to/starmine-token/venv/bin/gunicorn --workers 4 --bind 0.0.0.0:8000 "src.main:app"
Restart=always

[Install]
WantedBy=multi-user.target
```

4. Start and enable the service:

```bash
sudo systemctl start starmine
sudo systemctl enable starmine
```

### Nginx Configuration

1. Create an Nginx configuration file:

```bash
sudo nano /etc/nginx/sites-available/starmine
```

```
server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

2. Enable the site and get SSL certificate:

```bash
sudo ln -s /etc/nginx/sites-available/starmine /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
sudo certbot --nginx -d api.yourdomain.com
```

## Frontend Deployment

### Build the Frontend

1. Navigate to the frontend directory:

```bash
cd src/static
```

2. Install dependencies and build:

```bash
npm install
npm run build
```

### Configure Telegram Bot

1. Talk to BotFather on Telegram to create a new bot
2. Set the bot's description and about information
3. Set the bot's profile picture (use the StarMine logo)
4. Enable inline mode for the bot
5. Set up the bot's menu commands:
   - `/start` - Start mining stardust
   - `/status` - Check mining status
   - `/shop` - Visit the power-up shop
   - `/referral` - Get your referral code
   - `/leaderboard` - View the leaderboard

### Configure Mini App

1. Talk to BotFather and use the `/newapp` command
2. Set the app title to "StarMine Token"
3. Set the app description
4. Upload the app icon (use the StarMine logo)
5. Set the app URL to `https://api.yourdomain.com/webapp`
6. Configure the Web App settings:
   - Set the Mini App name to "StarMine"
   - Enable "Allow write access" for user data

### Integrate Wallet Pay

1. Talk to @wallet on Telegram
2. Use the `/newapp` command to create a payment app
3. Set the app name to "StarMine Token"
4. Set the app URL to `https://api.yourdomain.com/webapp`
5. Get the app ID and token
6. Update the payment configuration in `src/routes/store_routes.py`

## Testing the Deployment

1. Verify the API is working:
   - Visit `https://api.yourdomain.com/api/health`
   - Should return a JSON response with status "healthy"

2. Test the Telegram Mini App:
   - Open your bot in Telegram
   - Start the bot with `/start`
   - Tap on the Mini App button
   - Verify the app loads correctly

3. Test user registration:
   - The app should automatically register new users
   - Check the database to confirm user creation

4. Test mining functionality:
   - Start a mining session
   - Verify stardust accumulates correctly
   - Test collecting stardust

5. Test power-up purchases:
   - Try purchasing a power-up with stardust
   - Verify the power-up is added to the user's inventory
   - Test activating the power-up

6. Test TON payments:
   - Try purchasing Stellar Crystals with TON
   - Verify the payment flow works correctly
   - Check that Stellar Crystals are added to the user's account

## Monitoring and Maintenance

### Logging

1. Set up logging to a file:

```bash
sudo mkdir -p /var/log/starmine
sudo chown ubuntu:www-data /var/log/starmine
```

2. Update the systemd service file to include logging:

```
ExecStart=/path/to/starmine-token/venv/bin/gunicorn --workers 4 --bind 0.0.0.0:8000 --access-logfile /var/log/starmine/access.log --error-logfile /var/log/starmine/error.log "src.main:app"
```

3. Restart the service:

```bash
sudo systemctl daemon-reload
sudo systemctl restart starmine
```

### Database Backups

1. Set up a cron job for daily backups:

```bash
sudo crontab -e
```

```
0 2 * * * pg_dump -U starmine_user starmine > /path/to/backups/starmine_$(date +\%Y\%m\%d).sql
```

### Monitoring

1. Install and configure Prometheus and Grafana for monitoring
2. Set up alerts for server resource usage and application errors
3. Monitor user growth and engagement metrics

## Scaling Considerations

### Horizontal Scaling

1. Set up a load balancer for multiple API instances
2. Configure database read replicas for query-heavy operations
3. Implement Redis for caching and session management

### Performance Optimization

1. Optimize database queries and add indexes
2. Implement CDN for static assets
3. Use WebSockets for real-time updates

## Security Considerations

1. Regularly update dependencies
2. Implement rate limiting for API endpoints
3. Use HTTPS for all communications
4. Validate and sanitize all user inputs
5. Implement proper authentication and authorization

## Troubleshooting

### Common Issues

1. **App not loading in Telegram**:
   - Check Nginx configuration
   - Verify SSL certificate is valid
   - Ensure the app URL is correctly set in BotFather

2. **Database connection errors**:
   - Check database credentials
   - Verify PostgreSQL is running
   - Check firewall settings

3. **Payment issues**:
   - Verify Wallet Pay configuration
   - Check payment callback URLs
   - Test with small amounts first

### Support Resources

- Telegram Bot API documentation: https://core.telegram.org/bots/api
- Telegram Mini App documentation: https://core.telegram.org/bots/webapps
- TON Wallet Pay documentation: https://docs.ton.org/develop/dapps/ton-connect/wallet-apps/telegram-wallet
- Flask documentation: https://flask.palletsprojects.com/
- React documentation: https://reactjs.org/docs/getting-started.html

## Conclusion

Following this deployment guide will help you successfully deploy the StarMine Token Telegram Mini App. Regular monitoring and maintenance will ensure the app continues to function correctly and provide a great experience for users.

For any questions or issues, please contact the development team.
