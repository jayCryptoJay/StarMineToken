# StarMine Token - Referral & Incentive Features

## Referral System Overview

The StarMine referral system is designed to drive viral growth while complying with all Telegram Mini App guidelines. It leverages Telegram's native sharing capabilities and rewards both referrers and new players, creating a powerful network effect.

### Core Referral Mechanics

#### Referral Code Generation

- **Personal Referral Codes**: Each player receives a unique alphanumeric code (e.g., "STAR123XYZ")
- **Deep Link Integration**: Codes are embedded in Telegram deep links (t.me/StarMineBot?start=STAR123XYZ)
- **QR Code Option**: Players can share their referral code via a scannable QR code

#### Sharing Mechanisms

- **Direct Message Sharing**: Players can share their referral link directly to Telegram chats using Telegram.WebApp.shareMessage()
- **Story Sharing**: Players can share their mining achievements to Telegram Stories using Telegram.WebApp.shareToStory()
- **External Sharing**: Option to copy referral link for sharing outside Telegram

#### Referral Tracking

- **First-Time Attribution**: New players are attributed to the first referrer whose link they use
- **Persistent Tracking**: Referral relationships are stored server-side for ongoing rewards
- **Multi-Level Tracking**: System supports up to 3 levels of referrals (direct, 2nd-level, 3rd-level)

## Reward Structure

### Referrer Rewards

#### Immediate Rewards

- **Signup Bonus**: 500 Stardust when a referred player completes registration
- **Stellar Crystal Bonus**: 5 Stellar Crystals when a referred player reaches level 5
- **Special Equipment**: Exclusive "Cosmic Recruiter" mining equipment after 5 successful referrals

#### Ongoing Rewards

- **Mining Boost**: 5% passive mining rate boost for each active referred player (up to 25%)
- **Earnings Share**: 2% of stardust mined by direct referrals
- **Second-Level Share**: 0.5% of stardust mined by referrals of referrals

### Referee (New Player) Rewards

- **Welcome Bonus**: 1,000 Stardust upon signup using a referral code
- **Starter Pack**: Basic mining equipment with 20% better stats than default
- **Boost Period**: 24-hour mining rate boost (25% faster collection)

### Milestone Rewards

| Milestone | Referrer Reward | Special Bonus |
|-----------|-----------------|---------------|
| 1 Referral | 500 Stardust | "Recruiter" badge |
| 5 Referrals | 3,000 Stardust | "Cosmic Recruiter" equipment |
| 10 Referrals | 10,000 Stardust | "Stellar Ambassador" title |
| 25 Referrals | 30,000 Stardust | Exclusive "Nebula Harvester" power-up |
| 50 Referrals | 100,000 Stardust | "Galactic Influencer" profile frame |
| 100 Referrals | 300,000 Stardust | Limited edition "Cosmic Whale" avatar |

## Viral Growth Incentives

### Team Mining Mechanics

- **Mining Crews**: Players can form crews of up to 5 members
- **Crew Bonuses**: All crew members receive a 10% mining rate boost when online simultaneously
- **Crew Challenges**: Special high-reward missions available only to crews
- **Crew Leaderboard**: Special ranking for most productive mining crews

### Community Challenges

- **Global Mining Goals**: Community-wide targets that reward all participants when reached
- **Viral Events**: Limited-time events with escalating rewards based on total player participation
- **Cosmic Phenomena**: Random events that provide massive bonuses when enough players are active simultaneously

### Social Proof Elements

- **Live Activity Feed**: Real-time display of other players' achievements and rewards
- **Top Referrers Board**: Public recognition of players with most successful referrals
- **Recent Joiners**: Display of recently joined players through referral links

## Telegram-Specific Integration

### Native Telegram Features

- **Telegram.WebApp.shareMessage()**: Used for sharing referral links to chats
- **Telegram.WebApp.shareToStory()**: Used for sharing mining achievements to Stories
- **Bot API Integration**: Referral tracking through start parameters
- **Mini App Launch Methods**: Support for all six Telegram launch methods with proper referral attribution

### Privacy Compliance

- **User Consent**: Clear opt-in for referral program participation
- **Data Minimization**: Only essential data stored for referral tracking
- **Transparency**: Clear explanation of how referral data is used
- **User Control**: Option to disable referral tracking

## Monetization Integration

### TON & Wallet Pay Integration

- **Premium Referral Tiers**: Unlock higher referral rewards with TON purchases
- **Referral Boosters**: Purchase special items that increase referral rewards
- **Gift Purchases**: Send power-ups as gifts to referrals using Wallet Pay
- **Subscription Benefits**: Subscribers receive enhanced referral rewards

### Telegram Stars Integration

- **Stars Rewards**: Earn Telegram Stars for successful referrals
- **Stars Gifting**: Use Stars to send gifts to referrals
- **Exclusive Content**: Unlock special mining areas with Stars

## Technical Implementation

### Referral Link Structure

```
https://t.me/StarMineBot?start=REF_CODE
```

Where REF_CODE is a unique identifier for the referrer.

### Referral Data Storage

- **User Collection**: Stores user profiles with referral relationships
- **Referral Collection**: Tracks all referral events and rewards
- **Analytics Collection**: Aggregates referral performance metrics

### Security Measures

- **Anti-Fraud Detection**: Algorithms to detect and prevent referral abuse
- **Rate Limiting**: Caps on referral rewards to prevent exploitation
- **Verification Steps**: Multi-step verification for high-value referral rewards

## User Experience

### Referral Dashboard

- **Performance Metrics**: Visual display of referral statistics
- **Reward History**: Detailed log of all referral rewards received
- **Sharing Tools**: Easy access to all sharing options
- **Personalized Link**: Customizable referral message

### Onboarding Flow

1. **Discovery**: New users learn about referral program during tutorial
2. **Activation**: Prompt to share referral link after first successful mining session
3. **Reminder**: Periodic gentle reminders about referral benefits
4. **Celebration**: Visual celebration when referral milestones are reached

### Notification System

- **Referral Success**: Alert when someone uses your referral code
- **Reward Earned**: Notification when referral rewards are credited
- **Milestone Proximity**: Alert when approaching referral milestones
- **Special Opportunities**: Notification about limited-time referral bonuses

## Growth Hacking Features

### Limited-Time Promotions

- **Double Rewards**: Periodic events with doubled referral rewards
- **Flash Bonuses**: Surprise short-duration reward multipliers
- **First-Mover Advantage**: Extra rewards for early referrals during game launch

### Viral Loops

- **Multi-Stage Rewards**: Escalating rewards as referred players refer others
- **Group Completion Bonuses**: Rewards for completing "referral circles" where referred players refer each other
- **Viral Challenges**: Time-limited challenges requiring team formation through referrals

### Retention Hooks

- **Ongoing Relationship**: Continued benefits from active referred players
- **Reunion Bonuses**: Rewards for bringing back lapsed players
- **Mentor System**: Special gameplay advantages when playing with referred players

## Measurement & Optimization

### Key Performance Indicators

- **Referral Conversion Rate**: Percentage of shared links that result in new players
- **K-Factor**: Viral coefficient measuring growth rate
- **Cost Per Referral**: Effective cost of acquiring users through referrals
- **Referral Revenue**: Revenue generated from referred players
- **Referral ROI**: Return on investment from referral program

### A/B Testing Framework

- **Reward Structures**: Testing different reward amounts and types
- **Messaging Variations**: Testing different referral messaging
- **UI Placement**: Testing different placements of referral elements
- **Timing**: Testing optimal timing for referral prompts

### Optimization Cycle

1. **Measure**: Track all referral metrics
2. **Analyze**: Identify bottlenecks and opportunities
3. **Hypothesize**: Develop theories for improvement
4. **Test**: Implement A/B tests
5. **Iterate**: Apply learnings and repeat

## Compliance & Platform Guidelines

### Telegram Mini App Compliance

- **No Spam**: Referral system designed to prevent spam behavior
- **User Control**: Users can opt out of referral communications
- **Content Guidelines**: All referral messages comply with Telegram content policies
- **Technical Requirements**: Implementation follows all Telegram Mini App technical guidelines

### TON Blockchain Integration

- **Transparent Transactions**: All TON-based rewards clearly documented
- **Smart Contract Security**: Secure implementation of any blockchain-based rewards
- **Wallet Integration**: Seamless connection with TON wallets for rewards

### Data Protection

- **Data Minimization**: Only essential data collected for referral tracking
- **Secure Storage**: All referral data securely stored
- **User Transparency**: Clear explanation of data usage in privacy policy
- **Deletion Rights**: Option for users to delete their referral data

## Launch & Growth Strategy

### Phased Rollout

1. **Alpha Phase**: Invite-only referrals for early testers
2. **Beta Phase**: Limited referral program with core features
3. **Full Launch**: Complete referral system with all features
4. **Expansion Phase**: Additional referral features and optimizations

### Community Building

- **Referral Champions**: Special recognition for top referrers
- **Community Challenges**: Collaborative goals that reward the entire community
- **Feedback Loop**: Regular collection of user feedback on referral experience

### Influencer Strategy

- **Creator Program**: Special referral links for content creators
- **Enhanced Rewards**: Higher reward rates for verified influencers
- **Custom Tracking**: Detailed analytics for influencer referrals
- **Exclusive Content**: Special in-game content for influencer communities
